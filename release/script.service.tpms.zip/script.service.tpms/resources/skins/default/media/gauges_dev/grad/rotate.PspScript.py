from PSPApp import *


def ScriptProperties():
    return {
        'Author': u'',
        'Copyright': u'',
        'Description': u'',
        'Host': u'Paint Shop Pro X',
        'Host Version': u'10.10'
    }


def Do(Environment):
    rotate = 1
    while rotate < 360:
        # EnableOptimizedScriptUndo
        App.Do(Environment, 'EnableOptimizedScriptUndo', {
            'GeneralSettings': {
                'ExecutionMode': App.Constants.ExecutionMode.Default,
                'AutoActionMode': App.Constants.AutoActionMode.Match,
                'Version': ((10, 1, 0), 1)
            }
        })

        # Rotate
        App.Do(Environment, 'Rotate', {
            'RotAngleDegrees': rotate,
            'Direction': False,
            'Rotate All Layers': False,
            'FillMaterial': {
                'Color': (255, 255, 255),
                'Pattern': None,
                'Gradient': None,
                'Texture': None,
                'Art': None
            },
            'Rotate single layer around canvas center': True,
            'GeneralSettings': {
                'ExecutionMode': App.Constants.ExecutionMode.Default,
                'AutoActionMode': App.Constants.AutoActionMode.Match,
                'Version': ((10, 1, 0), 1)
            }
        })

        # FileSaveAs
        App.Do(Environment, 'FileSaveAs', {
            'Encoding': {
                'PNG': {
                    'Interlaced': False,
                    'OptimizedPalette': False,
                    'AlphaChannel': False
                }
            },
            'FileName': u'C:\\Users\\Christian\\VBOXTRANSFER\\BMW\\BMW Rasp OSMC Files\\Addons\\p' \
                        u'lugin.script.ibuscommunicator2\\resources\\skins\\Default\\media\\gauges\\gradnew\\' \
                        u'IBusOBCGAUGE_pin_%s.png' % rotate,
            'FileFormat': App.Constants.FileFormat.PNG,
            'FormatDesc': u'PNG Portable Network Graphics',
            'GeneralSettings': {
                'ExecutionMode': App.Constants.ExecutionMode.Default,
                'AutoActionMode': App.Constants.AutoActionMode.AllAlways,
                'Version': ((10, 1, 0), 1)
            },
            'DefaultProperties': []
        })
        rotate += 1
