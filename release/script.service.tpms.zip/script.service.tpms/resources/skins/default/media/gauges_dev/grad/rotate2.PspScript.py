from PSPApp import *

def ScriptProperties():
    return {
        'Author': u'',
        'Copyright': u'',
        'Description': u'',
        'Host': u'Paint Shop Pro X',
        'Host Version': u'10.10'
        }

def Do(Environment):
    rotate = 1
    while rotate < 360:
        rotate_tmp = '%s' % rotate
        if len(rotate_tmp) == 1:
            rotate_tmp = rotate_tmp.zfill(3)
        elif len(rotate_tmp) == 2:
            rotate_tmp = rotate_tmp.zfill(2)
        # EnableOptimizedScriptUndo
        App.Do( Environment, 'EnableOptimizedScriptUndo', {
                'GeneralSettings': {
                    'ExecutionMode': App.Constants.ExecutionMode.Default,
                    'AutoActionMode': App.Constants.AutoActionMode.Match,
                    'Version': ((10,1,0),1)
                    }
                })

        # FileOpen
        App.Do( Environment, 'FileOpen', {
                'FileList': [u'C:\\Users\\Christian\\VBOXTRANSFER\\BMW\\BMW Rasp OSMC Files\\Addons\\'\
                    u'plugin.script.ibuscommunicator2\\resources\\skins\\Default\\media\\gauges\\IBus'\
                    u'OBCGAUGE_pin.png'],
                'Folder': u'C:\\Users\\Christian\\VBOXTRANSFER\\BMW\\BMW Rasp OSMC Files\\Addons\\plu'\
                    u'gin.script.ibuscommunicator2\\resources\\skins\\Default\\media\\gauges',
                'FileFormat': App.Constants.FileFormat.PNG,
                'ShowPreview': True,
                'EnableBrowser': True,
                'FavFileList': [],
                'RawCameraSettings': {
                    'WhiteBalance': App.Constants.WhiteBalance.AsShot,
                    'SharpenMode': App.Constants.SharpenMode.Low,
                    'Exposure': 0,
                    'Rect': ((0,0), 0, 0),
                    'ShowMaximized': False,
                    'ShowPreview': False
                    },
                'FileOpenScript': u'',
                'EnablePreprocessing': False,
                'GeneralSettings': {
                    'ExecutionMode': App.Constants.ExecutionMode.Default,
                    'AutoActionMode': App.Constants.AutoActionMode.Match,
                    'Version': ((10,1,0),1)
                    }
                })

        # SelectDocument
        App.Do( Environment, 'SelectDocument', {
                'SelectedImage': 0,
                'Strict': False,
                'GeneralSettings': {
                    'ExecutionMode': App.Constants.ExecutionMode.Default,
                    'AutoActionMode': App.Constants.AutoActionMode.Match,
                    'Version': ((10,1,0),1)
                    }
                })

        # Rotate
        App.Do( Environment, 'Rotate', {
                'RotAngleDegrees': 180,
                'Direction': False,
                'Rotate All Layers': False,
                'FillMaterial': {
                    'Color': (255,255,255),
                    'Pattern': None,
                    'Gradient': None,
                    'Texture': None,
                    'Art': None
                    },
                'Rotate single layer around canvas center': True,
                'GeneralSettings': {
                    'ExecutionMode': App.Constants.ExecutionMode.Default,
                    'AutoActionMode': App.Constants.AutoActionMode.Match,
                    'Version': ((10,1,0),1)
                    }
                })

        # Rotate
        App.Do( Environment, 'Rotate', {
                'RotAngleDegrees': rotate,
                'Direction': False,
                'Rotate All Layers': False,
                'FillMaterial': {
                    'Color': (255,255,255),
                    'Pattern': None,
                    'Gradient': None,
                    'Texture': None,
                    'Art': None
                    },
                'Rotate single layer around canvas center': True,
                'GeneralSettings': {
                    'ExecutionMode': App.Constants.ExecutionMode.Default,
                    'AutoActionMode': App.Constants.AutoActionMode.Match,
                    'Version': ((10,1,0),1)
                    }
                })

        # FileSaveAs
        App.Do( Environment, 'FileSaveAs', {
                'Encoding': {
                    'PNG': {
                        'Interlaced': False,
                        'OptimizedPalette': False,
                        'AlphaChannel': False
                        }
                    },
                'FileName': u'C:\\Users\\Christian\\VBOXTRANSFER\\BMW\\BMW Rasp OSMC Files\\Addons\\p'\
                    u'lugin.script.ibuscommunicator2\\resources\\skins\\Default\\media\\gauges\\gradn'\
                    u'ew\\IBusOBCGAUGE_pin_%s.png' % rotate_tmp,
                'FileFormat': App.Constants.FileFormat.PNG,
                'FormatDesc': u'PNG Portable Network Graphics',
                'GeneralSettings': {
                    'ExecutionMode': App.Constants.ExecutionMode.Default,
                    'AutoActionMode': App.Constants.AutoActionMode.AllAlways,
                    'Version': ((10,1,0),1)
                    },
                'DefaultProperties': []
                })

        # FileClose
        App.Do( Environment, 'FileClose', {
                'GeneralSettings': {
                    'ExecutionMode': App.Constants.ExecutionMode.Silent,
                    'AutoActionMode': App.Constants.AutoActionMode.Match,
                    'Version': ((10,1,0),1)
                    }
                })

        # SelectDocument
        App.Do( Environment, 'SelectDocument', {
                'SelectedImage': 0,
                'Strict': False,
                'GeneralSettings': {
                    'ExecutionMode': App.Constants.ExecutionMode.Default,
                    'AutoActionMode': App.Constants.AutoActionMode.Match,
                    'Version': ((10,1,0),1)
                    }
                })
        rotate += 1
