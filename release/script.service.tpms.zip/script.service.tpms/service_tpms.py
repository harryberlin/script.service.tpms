#!/usr/bin/python
# -*- coding: UTF-8 -*-

'''
eventACK 0x55, 0xAA, 0x06, 0x00, 0x00, 0x00

Heartbeat 55 AA, 0x06, 0x19, 0x00, 0xE0

?? 0x55, 0xAA, 0x06, 0x5B, ??, 0xE0

pairingSensorLeftBack 0x55, 0xAA, 0x06, 0x01, 0x10, 0x00

pairingSensorBackRight 0x55, 0xAA, 0x06, 0x01, 0x11, 0x00

pairingSensorFrontLeft 0x55, 0xAA, 0x06, 0x01, 0x00, 0x00

pairingSensorFrontRight 0x55, 0xAA, 0x06, 0x01, 0x01, 0x00

pairingSensorSpareTire 55, AA 0x06, 0x01, 0x05, 0x00

querySensorsID 0x55, 0xAA, 0x06, 0x07, 0x00, 0x00

stopPairing 0x55, 0xAA, 0x06, 0x06, 0x00, 0x00

wheelsChangeLeftFrontRightFront 0x55, 0xAA, 0x07, 0x03, 0x00, 0x01, 0x00

wheelsChangeLeftFrontLeftBack 0x55, 0xAA, 0x07, 0x03, 0x00, 10, 0x00

wheelsChangeLeftFrontRightBack 0x55, 0xAA, 0x07, 0x03, 0x00, 11, 0x00

wheelsChangeRightFrontLeftBack 0x55, 0xAA, 0x07, 0x03, 0x01, 0x10, 0x00

wheelsChangeRightFrontRightBack 0x55, 0xAA, 0x07, 0x03, 0x01, 0x11, 0x00

wheelsChangeLeftBackRightBack 0x55, 0xAA, 0x07, 0x03, 0x10, 0x11, 0x00

wheelsChangeSpareFrontLeft 0x55, 0xAA, 0x07, 0x03, 0x00, 0x05, 0x00

wheelsChangeSpareFrontRight 0x55, 0xAA, 0x07, 0x03, 0x01, 0x05, 0x00

wheelsChangeSpareBackLeft 0x55, 0xAA, 0x07, 0x03, 0x10, 0x05, 0x00

wheelsChangeSpareBackRight 0x55, 0xAA, 0x7, 0x3, 0x11, 0x05, 0x00

reset 0x55, 0xAA, 0x06, 0x58, 0x55, 0xE0
'''


__author__ = 'harryberlin'

import sys
import os
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs


ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_USER_PATH = os.path.join(xbmc.translatePath('special://userdata'), 'addon_data', ADDON_ID)


ADDON_SKIN_MEDIA_PATH = os.path.join(ADDON_PATH, 'resources', 'skins', 'default', 'media')

ADDON_ICON = os.path.join(ADDON_PATH, 'icon.png')

ADDON_COLOR_YELLOW = 'FFE6C819' #'FFf8c300'
ADDON_COLOR_GREEN  = 'FF3BFC00' #'FF84c225'
ADDON_COLOR_BLUE   = 'FF007CC3'
ADDON_COLOR_RED    = 'FFDB214C'
ADDON_COLOR_AMBER  = 'FFFF7E00'  # BMW Amber FFFF7E00
ADDON_COLOR_WHITE  = 'FFFFFFFF'
ADDON_COLOR_BLACK  = 'FF000000'
# color = 'FF0084FF' # blue
# color = 'FFEEEEFF' # white

ADDON_TIRE_COLOR_RED    = 'CCFF0033'
ADDON_TIRE_COLOR_YELLOW = 'CCFFFF55'
ADDON_TIRE_COLOR_GREEN  = 'CC33FF00'
ADDON_TIRE_COLOR_BLUE   = 'CC0055FF'
ADDON_TIRE_COLOR_GREY   = 'CC555555'

FRONT_LEFT = '1'
FRONT_RIGHT = '2'
REAR_LEFT = '3'
REAR_RIGHT = '4'
SQUARE = '5'

# add librarys and resource files into sys path
BASE_RESOURCE_PATH = os.path.join(ADDON_PATH, 'resources')
BASE_LIB_PATH = os.path.join(ADDON_PATH, 'resources', 'lib')
sys.path.append(BASE_RESOURCE_PATH)
sys.path.append(BASE_LIB_PATH)

import math
import json
import time
import serial
import socket
import logging
import zipfile
import platform
import subprocess
from re import findall, split, DOTALL
from datetime import datetime
from functools import partial
#from resources.lib.kodi_actions import KODI_ACTIONS
from threading import Thread, Lock, Event

class RepeatTimer(Thread):
    def __init__(self, interval, function, iterations=0, args=[], kwargs={}):
        Thread.__init__(self)
        self.daemon = True
        self.interval = interval
        self.function = function
        self.iterations = iterations
        self.args = args
        self.kwargs = kwargs
        self.finished = Event()

    def run(self):
        count = 0
        while not self.finished.isSet() and (self.iterations <= 0 or count < self.iterations):
            self.finished.wait(self.interval)
            if not self.finished.isSet():
                self.function(*self.args, **self.kwargs)
                count += 1
        log('Timer Thread finished')

    def cancel(self):
        self.finished.set()


class Kodi(object):


    def __init__(self):
        self.xbmc = xbmc

    def up(self, steps='01'):
        steps = int(steps, 16)
        while steps > 0:
            self.xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Up", "id": 1 }')
            steps -= 1
            time.sleep(0.020)

    def down(self, steps='01'):
        steps = int(steps, 16)
        while steps > 0:
            self.xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Down", "id": 1 }')
            steps -= 1
            time.sleep(0.020)

    def left(self):
        self.xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Left", "id": 1 }')

    def right(self):
        self.xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Right", "id": 1 }')

    def back(self):
        self.xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Back", "id": 1 }')
        #self.builtin_function('Action(Back)')

    def select(self):
        self.xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Select", "id": 1 }')

    def home(self):
        #if xbmcgui.getCurrentWindowDialogId() != 9999:
        self.xbmc.executebuiltin('Dialog.Close(all,true)')  # self.back()
        self.xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Home", "id": 1 }')

    def volume_up(self, steps='01'):
        steps = int(steps, 16)
        while steps > 0:
            self.xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Application.SetVolume", "params": { "volume": "increment" }, "id": 1 }')
            steps -= 1
            time.sleep(0.080)

    def volume_down(self, steps='01'):
        steps = int(steps, 16)
        while steps > 0:
            self.xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Application.SetVolume", "params": { "volume": "decrement" }, "id": 1 }')
            steps -= 1
            time.sleep(0.080)


    def builtin_function(self, action_event):
        '''

        :param action_event: use https://kodi.wiki/view/List_of_built-in_functions
        :return: xbmc.executebuiltin
        '''

        log('KODI ACTION EVENT: %s' % action_event)

        # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.ExecuteAction","params": {"action": "%s"},"id":1}' % action_event)
        self.xbmc.executebuiltin('%s' % action_event)


    def get_condition(self, condition):
        return bool(self.xbmc.getCondVisibility(condition))

    def get_gui_version(self):
        return '%s' % xbmcaddon.Addon('xbmc.gui').getAddonInfo('version')

    def log(self, string, lvl=1):
        if self.log_level < 1 and lvl > 0: return

        log_it = False

        if lvl <= self.log_level <= 3:
            log_it = True
        if self.log_level in [4] and lvl in [4]:
            log_it = True
        if self.log_level in [5] and lvl in [5]:
            log_it = True
            #string = unidecode(string)
            #string = string.decode('iso-8859-1').encode('latin1')
        if log_it:
            if self.log_to_kodi:
                try:
                    circle_char =  self.circle[self.circle_counter]
                except:
                    self.circle_counter = 0
                    circle_char = self.circle[self.circle_counter]

                self.xbmc.log('IBUSCOMMUNICATOR: %s %s' % (circle_char, string), xbmc.LOGNOTICE)

                if self.circle_counter + 1 > 2:
                    self.circle_counter = 0
                else:
                    self.circle_counter += 1
            else:
                if self.log_level < 5:
                    self.ibuslogger.log('%s' % string) # .decode('utf-8').encode("iso-8859-1")

        if self.log_level >= 1 and lvl == 5 and not self.log_to_kodi:
            self.ibusdatalogger.log('%s' % string) # .decode('utf-8').encode("iso-8859-1")

class MonitorClass(xbmc.Monitor):
    def __init__(self):
        xbmc.Monitor.__init__(self)
        self.settings_changed_callback = None

    def onSettingsChanged(self):
        # log('SETTINGS: ################ CHANGED ###############',0)
        #xbmc.sleep(1000) # short sleep to get effect
        #note('Settings changed', 'Reloading...', 1000)
        if self.settings_changed_callback is not None:
            self.settings_changed_callback()

    def set_settings_changed_callback(self, event):
        self.settings_changed_callback = event



class GuiClass(xbmcgui.WindowXML):

    ACTION_PARENT_DIR = 9
    ACTION_PREVIOUS_MENU = 10
    ACTION_CLOSE_DIALOG = 51
    ACTION_SELECT_ITEM = 7
    ACTION_MOVE_LEFT = 1
    ACTION_MOVE_RIGHT = 2
    ACTION_MOVE_UP = 3
    ACTION_MOVE_DOWN = 4
    ACTION_NAV_BACK = 92
    ACTION_BACKSPACE = 110
    ACTION_MOUSE_LEFT_CLICK = 100
    ACTION_SHOW_FULLSCREEN = 36

    def __init__(self, xmlFilename, scriptPath, defaultSkin, defaultRes):
        log("Initializing OBC Gui...")
        self.event_object = EventClass
        set_property('script.service.tpms_gui_loaded', '0')

        self.obc_screen = 0
        self.obc_screen_min = -1
        self.obc_screen_max = -1

        self.tire_fl = None
        self.tire_rl = None
        self.tire_fr = None
        self.tire_rr = None

        self.battery_fl = None
        self.battery_rl = None
        self.battery_fr = None
        self.battery_rr = None

        self.signal_fl = None
        self.signal_rl = None
        self.signal_fr = None
        self.signal_rr = None

        self.MAINLABEL = {}
        self.BUTTON1 = {}
        self.BUTTON2 = {}
        self.BUTTON3 = {}
        self.BUTTON4 = {}
        self.BUTTON5 = {}
        self.BUTTON6 = {}
        self.BUTTON7 = {}
        self.BUTTON8 = {}

        self.LABEL1 = {}
        self.LABEL2 = {}
        self.LABEL3 = {}
        self.LABEL4 = {}
        self.LABEL5 = {}
        self.LABEL6 = {}
        self.LABEL7 = {}
        self.LABEL8 = {}

        self.IMAGE1 = {}
        self.IMAGE2 = {}
        self.IMAGE3 = {}
        self.IMAGE4 = {}
        self.IMAGE5 = {}
        self.IMAGE6 = {}
        self.IMAGE7 = {}
        self.IMAGE8 = {}

        #         [imgae, label]
        self.GAUGE_L = [None, None]
        self.GAUGE_M = [None, None]
        self.GAUGE_R = [None, None]

        self.isActive = False

        self.mouse_clicked = False

        self.updateTimer = None
        self.updateObc = None
        self.submenuCounter = None

        self.pause_submenu_counter = False
        self.window_id = -10000
        #self.obc_set_value = ObcSetValueClass('OBC_SETVALUE.xml', ADDON_PATH, 'default', '720p')

        self.gauges_sliding = False

        self.counter = 0



    def isVisible(self):
        log('GUI: VISIBLE: WINDOW ID: %s' % xbmcgui.getCurrentWindowId(), 2)
        #xbmcgui.getCurrentWindowId()
        #if self.isActive and xbmcgui.getCurrentWindowId() == self.window_id:
        if self.isActive and bool(xbmc.getCondVisibility('Window.IsActive(%s)' % self.window_id)):
            return True
        else:
            return False

    def onInit(self):
        log('OBC INIT: WINDOW ID: %s' % xbmcgui.getCurrentWindowId())
        self.window_id = xbmcgui.getCurrentWindowId()

        ## BUTTON OBC-Screen[Text, Visible, Enable]
        ## LABEL OBC-Screen[Text, Visible, Enable, Submenu, SubEvents]
        ## IMAGE OBC-Screen[Visible]

        '''
        self.obc_screen_min = 0
        self.obc_screen_max = 4

        
        # OBC 0
        self.MAINLABEL[0] = ['ON-BOARD', True, True]
        self.BUTTON1[0], self.LABEL1[0], self.IMAGE1[0] = self.CONS1
        self.BUTTON2[0], self.LABEL2[0], self.IMAGE2[0] = self.CONS2
        self.BUTTON3[0], self.LABEL3[0], self.IMAGE3[0] = self.RANGE
        self.BUTTON4[0], self.LABEL4[0], self.IMAGE4[0] = self.FUELLEVEL
        self.BUTTON5[0], self.LABEL5[0], self.IMAGE5[0] = self.DIST
        self.BUTTON6[0], self.LABEL6[0], self.IMAGE6[0] = self.ARR
        self.BUTTON7[0], self.LABEL7[0], self.IMAGE7[0] = self.LIMIT
        self.BUTTON8[0], self.LABEL8[0], self.IMAGE8[0] = self.SPEED

        # OBC 1
        self.MAINLABEL[1] = [language('ON-BOARD'), True, True]
        self.BUTTON1[1], self.LABEL1[1], self.IMAGE1[1] = self.AVG
        self.BUTTON2[1], self.LABEL2[1], self.IMAGE2[1] = self.MEMO
        self.BUTTON3[1], self.LABEL3[1], self.IMAGE3[1] = self.STPWTCH
        self.BUTTON4[1], self.LABEL4[1], self.IMAGE4[1] = self.EMPTY
        self.BUTTON5[1], self.LABEL5[1], self.IMAGE5[1] = self.TMR1
        self.BUTTON6[1], self.LABEL6[1], self.IMAGE6[1] = self.TMR2
        self.BUTTON7[1], self.LABEL7[1], self.IMAGE7[1] = self.AUXVENT
        self.BUTTON8[1], self.LABEL8[1], self.IMAGE8[1] = self.AUXHEAT

        # OBC 2 - Info
        self.MAINLABEL[2] = [language('INFORMATION'), True, True]
        self.BUTTON1[2], self.LABEL1[2], self.IMAGE1[2] = self.KEYS
        self.BUTTON2[2], self.LABEL2[2], self.IMAGE2[2] = self.ODOMETER
        self.BUTTON3[2], self.LABEL3[2], self.IMAGE3[2] = self.VIN
        self.BUTTON4[2], self.LABEL4[2], self.IMAGE4[2] = self.RPM
        self.BUTTON5[2], self.LABEL5[2], self.IMAGE5[2] = self.COOLANT
        self.BUTTON6[2], self.LABEL6[2], self.IMAGE6[2] = self.OILTEMP if EVENT.oil_temp_enable else self.CARMODEL
        self.BUTTON7[2], self.LABEL7[2], self.IMAGE7[2] = self.VOLTAGE
        self.BUTTON8[2], self.LABEL8[2], self.IMAGE8[2] = self.LANGUAGE

        # OBC 3 - GPS
        self.MAINLABEL[3] = [language('GPS'), True, True]
        self.BUTTON1[3], self.LABEL1[3], self.IMAGE1[3] = self.GPSFIX
        self.BUTTON2[3], self.LABEL2[3], self.IMAGE2[3] = self.GPSTOWN
        self.BUTTON3[3], self.LABEL3[3], self.IMAGE3[3] = self.GPSSTREET
        self.BUTTON4[3], self.LABEL4[3], self.IMAGE4[3] = self.GPSLAT
        self.BUTTON5[3], self.LABEL5[3], self.IMAGE5[3] = self.GPSLON
        self.BUTTON6[3], self.LABEL6[3], self.IMAGE6[3] = self.GPSALT
        self.BUTTON7[3], self.LABEL7[3], self.IMAGE7[3] = self.EMPTY
        self.BUTTON8[3], self.LABEL8[3], self.IMAGE8[3] = self.EMPTY
        '''


        log('GUI Opening')

        self.isActive = True

        self.MAINLABEL = self.getControl(200)
        #self.mainleft = self.getControl(201)
        #self.mainright = self.getControl(202)

        '''
        self.IMAGE1[-1] = self.getControl(101)
        self.IMAGE2[-1] = self.getControl(102)
        self.IMAGE3[-1] = self.getControl(103)
        self.IMAGE4[-1] = self.getControl(104)
        self.IMAGE5[-1] = self.getControl(105)
        self.IMAGE6[-1] = self.getControl(106)
        self.IMAGE7[-1] = self.getControl(107)
        self.IMAGE8[-1] = self.getControl(108)
        '''

        self.button_fr = self.getControl(111)
        self.button_fl = self.getControl(112)
        self.button_rr = self.getControl(113)
        self.button_rl = self.getControl(114)

        self.tire_fl = self.getControl(141)
        self.tire_rl = self.getControl(142)
        self.tire_fr = self.getControl(143)
        self.tire_rr = self.getControl(144)

        self.battery_fl = self.getControl(101)
        self.battery_rl = self.getControl(102)
        self.battery_fr = self.getControl(103)
        self.battery_rr = self.getControl(104)

        self.signal_fl = self.getControl(131)
        self.signal_rl = self.getControl(132)
        self.signal_fr = self.getControl(133)
        self.signal_rr = self.getControl(134)

        '''
        self.BUTTON5[-1] = self.getControl(115)
        self.BUTTON6[-1] = self.getControl(116)
        self.BUTTON7[-1] = self.getControl(117)
        self.BUTTON8[-1] = self.getControl(118)
        '''
        '''
        self.LABEL1[-1] = self.getControl(121)
        self.LABEL2[-1] = self.getControl(122)
        self.LABEL3[-1] = self.getControl(123)
        self.LABEL4[-1] = self.getControl(124)
        self.LABEL5[-1] = self.getControl(125)
        self.LABEL6[-1] = self.getControl(126)
        self.LABEL7[-1] = self.getControl(127)
        self.LABEL8[-1] = self.getControl(128)
        '''

        # Bottom Line
        self.LABEL211 = self.getControl(211)


        self.update(startup=True)

        self.set_default_navigation()

        if self.updateTimer:
            self.updateTimer.cancel()
            self.updateTimer.join()
            delete_object(self.updateTimer)
        self.updateTimer = RepeatTimer(0.333, self.update)
        self.updateTimer.start()

        set_property('script.service.tpms_gui_loaded', '1')

        #note('obc gui loaded %s' % self.window_id)

    #'''
    def onMouseLeftClick(self, controlId):
        log('ONCLICK: %s' % controlId, 3)
        # self.mainleft = self.getControl(201)
        # self.mainright = self.getControl(202)

        if controlId == 201: # left
            self.obcPrev()
        elif controlId == 202: # right
            self.obcNext()

        elif 111 <= controlId <= 118: # Buttons
            self.click_submenu(controlId)
    #'''


    def onAction(self, Action):
        if Action in [self.ACTION_PREVIOUS_MENU, self.ACTION_CLOSE_DIALOG, self.ACTION_NAV_BACK, self.ACTION_BACKSPACE, self.ACTION_SHOW_FULLSCREEN]:
            self.onStop()

        log('OBCGUI ACTION ID: %s' % Action.getId(), 3)
        log('OBCGUI FOCUS ID: %s' % self.getFocusId(), 3)
        '''
        if Action == self.ACTION_MOUSE_LEFT_CLICK:
            log('OBCGUI MOUSE CLICKED', 3)
            self.onMouseLeftClick(self.getFocusId())
            return

        if Action == self.ACTION_MOVE_LEFT and self.obc_screen > self.obc_screen_min:  # left
            self.obcPrev()

        elif Action == self.ACTION_MOVE_RIGHT and self.obc_screen < self.obc_screen_max:  # right
            self.obcNext()

        elif Action == self.ACTION_SELECT_ITEM:
            if self.selectedButton < 0:
                if self.set_submenu(0):
                    self.counter_submenu()
            else:
                log('submenu selected')
                log('obc screen %s' % self.obc_screen)
                log('Button %s' % self.selectedButton)
                log('SubButton %s' % self.selectedSubButton)
                self.onSubmenuSelected(self.obc_screen, self.selectedButton, self.selectedSubButton)
                self.timeoutSubMenu = 0

        elif Action == self.ACTION_MOVE_UP:
            if self.selectedButton > 0:
                self.set_submenu(self.selectedSubButton - 1)
                #self.timeoutSubMenu = 2000
                self.counter_submenu()

            if self.obc_screen == self.obc_screen_max:
                if not self.gauges_sliding and EVENT.develop:
                    self.gauges_slide()

        elif Action == self.ACTION_MOVE_DOWN:
            if self.selectedButton > 0:
                self.set_submenu(self.selectedSubButton + 1)
                #self.timeoutSubMenu = 2000
                self.counter_submenu()
        '''
        log('OBCGUI FOCUSED ID: %s' % self.getFocusId(), 3)

    def onFocus(self, controlId):
        pass

    def onStop(self, close_window=True):
        log('GUI: Closing')
        #self.updateObc.cancel()
        #self.updateTimer.cancel()
        self.isActive = False

        # KODI.set_property('IBUSCOMMUNICATOR_OBC_LOADED', '0')

        #self.updateObc.join()
        #self.updateTimer.join()
        if self.submenuCounter:
            self.timeoutSubMenu = 0
            self.submenuCounter.join()
        log('Timers joined')

        #delete_object(self.updateObc)
        #delete_object(self.updateTimer)
        #delete_object(self.submenuCounter)

        '''
        self.MAINLABEL[-1] = None
        self.mainleft = None
        self.mainright = None

        self.IMAGE1[-1] = None
        self.IMAGE2[-1] = None
        self.IMAGE3[-1] = None
        self.IMAGE4[-1] = None
        self.IMAGE5[-1] = None
        self.IMAGE6[-1] = None
        self.IMAGE7[-1] = None
        self.IMAGE8[-1] = None

        self.BUTTON1[-1] = None
        self.BUTTON2[-1] = None
        self.BUTTON3[-1] = None
        self.BUTTON4[-1] = None
        self.BUTTON5[-1] = None
        self.BUTTON6[-1] = None
        self.BUTTON7[-1] = None
        self.BUTTON8[-1] = None

        self.LABEL1[-1] = None
        self.LABEL2[-1] = None
        self.LABEL3[-1] = None
        self.LABEL4[-1] = None
        self.LABEL5[-1] = None
        self.LABEL6[-1] = None
        self.LABEL7[-1] = None
        self.LABEL8[-1] = None

        self.GAUGE_L = [None, None]
        self.GAUGE_M = [None, None]
        self.GAUGE_R = [None, None]

        # Bottom Line
        self.LABEL211 = None
        '''

        if close_window:
            self.close()

        set_property('script.service.tpms_gui_loaded', '0')

    def set_default_navigation(self):
        '''
        self.BUTTON1[-1].setNavigation(self.BUTTON1[-1], self.BUTTON2[-1], self.BUTTON1[-1], self.BUTTON1[-1])
        self.BUTTON2[-1].setNavigation(self.BUTTON1[-1], self.BUTTON3[-1], self.BUTTON2[-1], self.BUTTON2[-1])
        self.BUTTON3[-1].setNavigation(self.BUTTON2[-1], self.BUTTON4[-1], self.BUTTON3[-1], self.BUTTON3[-1])
        self.BUTTON4[-1].setNavigation(self.BUTTON3[-1], self.BUTTON5[-1], self.BUTTON4[-1], self.BUTTON4[-1])
        self.BUTTON5[-1].setNavigation(self.BUTTON4[-1], self.BUTTON6[-1], self.BUTTON5[-1], self.BUTTON5[-1])
        self.BUTTON6[-1].setNavigation(self.BUTTON5[-1], self.BUTTON7[-1], self.BUTTON6[-1], self.BUTTON6[-1])
        self.BUTTON7[-1].setNavigation(self.BUTTON6[-1], self.BUTTON8[-1], self.BUTTON7[-1], self.BUTTON7[-1])
        self.BUTTON8[-1].setNavigation(self.BUTTON7[-1], self.BUTTON8[-1], self.BUTTON8[-1], self.BUTTON8[-1])
        '''
        #setNavigation(up, down, left, right)
        self.button_fr.setNavigation(self.button_fr, self.button_fl, self.button_fr, self.button_rr)
        self.button_fl.setNavigation(self.button_fr, self.button_rr, self.button_fl, self.button_rl)
        self.button_rr.setNavigation(self.button_fl, self.button_rl, self.button_fr, self.button_rr)
        self.button_rl.setNavigation(self.button_rr, self.button_rl, self.button_fl, self.button_rl)

    def set_submenu(self, menu_pos):
        if self.getFocusId() == 111:
            label_textlist = self.LABEL1
            label_control = self.LABEL1[-1]
            self.selectedButton = 1
            button_control = self.BUTTON1[-1]
        elif self.getFocusId() == 112:
            label_textlist = self.LABEL2
            label_control = self.LABEL2[-1]
            self.selectedButton = 2
            button_control = self.BUTTON2[-1]
        elif self.getFocusId() == 113:
            label_textlist = self.LABEL3
            label_control = self.LABEL3[-1]
            self.selectedButton = 3
            button_control = self.BUTTON3[-1]
        elif self.getFocusId() == 114:
            label_textlist = self.LABEL4
            label_control = self.LABEL4[-1]
            self.selectedButton = 4
            button_control = self.BUTTON4[-1]
        elif self.getFocusId() == 115:
            label_textlist = self.LABEL5
            label_control = self.LABEL5[-1]
            self.selectedButton = 5
            button_control = self.BUTTON5[-1]
        elif self.getFocusId() == 116:
            label_textlist = self.LABEL6
            label_control = self.LABEL6[-1]
            self.selectedButton = 6
            button_control = self.BUTTON6[-1]
        elif self.getFocusId() == 117:
            label_textlist = self.LABEL7
            label_control = self.LABEL7[-1]
            self.selectedButton = 7
            button_control = self.BUTTON7[-1]
        elif self.getFocusId() == 118:
            label_textlist = self.LABEL8
            label_control = self.LABEL8[-1]
            self.selectedButton = 8
            button_control = self.BUTTON8[-1]
        else:
            return False

        if not len(label_textlist[self.obc_screen][3]) > 0:
            self.selectedButton = -1
            self.selectedSubButton = -1
            return False

        if menu_pos < 0:
            menu_pos = len(label_textlist[self.obc_screen][3]) - 1
        elif menu_pos > len(label_textlist[self.obc_screen][3]) - 1:
            menu_pos = 0

        if label_textlist[self.obc_screen][3][menu_pos]:
            label_control.setLabel(' ')
            time.sleep(0.100)
            color = ADDON_COLOR_AMBER

            label_control.setLabel('[COLOR %s]- %s -[/COLOR]' % (color, label_textlist[self.obc_screen][3][menu_pos]))
            self.selectedSubButton = menu_pos
            button_control.setNavigation(button_control, button_control, button_control, button_control)
            return True
        else:
            self.selectedButton = -1
            self.selectedSubButton = -1
            return False

    def reset_submenu(self):
        self.selectedButton = -1
        self.selectedSubButton = -1

        self.update()
        self.set_default_navigation()

    def click_submenu(self, item):
        '''
        item = 111 - 118
        '''
        if item == 111:
            header = self.BUTTON1[self.obc_screen][0]
            obc_event_list = self.LABEL1[self.obc_screen][3]
            obc_event_action = self.LABEL1[self.obc_screen][4]
        elif item == 112:
            header = self.BUTTON2[self.obc_screen][0]
            obc_event_list = self.LABEL2[self.obc_screen][3]
            obc_event_action = self.LABEL2[self.obc_screen][4]
        elif item == 113:
            header = self.BUTTON3[self.obc_screen][0]
            obc_event_list = self.LABEL3[self.obc_screen][3]
            obc_event_action = self.LABEL3[self.obc_screen][4]
        elif item == 114:
            header = self.BUTTON4[self.obc_screen][0]
            obc_event_list = self.LABEL4[self.obc_screen][3]
            obc_event_action = self.LABEL4[self.obc_screen][4]
        elif item == 115:
            header = self.BUTTON5[self.obc_screen][0]
            obc_event_list = self.LABEL5[self.obc_screen][3]
            obc_event_action = self.LABEL5[self.obc_screen][4]
        elif item == 116:
            header = self.BUTTON6[self.obc_screen][0]
            obc_event_list = self.LABEL6[self.obc_screen][3]
            obc_event_action = self.LABEL6[self.obc_screen][4]
        elif item == 117:
            header = self.BUTTON7[self.obc_screen][0]
            obc_event_list = self.LABEL7[self.obc_screen][3]
            obc_event_action = self.LABEL7[self.obc_screen][4]
        elif item == 118:
            header = self.BUTTON8[self.obc_screen][0]
            obc_event_list = self.LABEL8[self.obc_screen][3]
            obc_event_action = self.LABEL8[self.obc_screen][4]

        if len(obc_event_list) > 0:
            selected = xbmcgui.Dialog().select(header, obc_event_list)
            #xbmcgui.Dialog().ok(header, '%s' % selected, '%s' % obc_event_action[selected])
            if selected > -1:
                self.mouse_clicked = True
                obc_event_action[selected]()
                self.mouse_clicked = False



    def onSubmenuSelected(self, obc_screen, button, sub_button):
        if button == 1:
            obc_event = self.LABEL1[obc_screen][4]
        elif button == 2:
            obc_event = self.LABEL2[obc_screen][4]
        elif button == 3:
            obc_event = self.LABEL3[obc_screen][4]
        elif button == 4:
            obc_event = self.LABEL4[obc_screen][4]
        elif button == 5:
            obc_event = self.LABEL5[obc_screen][4]
        elif button == 6:
            obc_event = self.LABEL6[obc_screen][4]
        elif button == 7:
            obc_event = self.LABEL7[obc_screen][4]
        elif button == 8:
            obc_event = self.LABEL8[obc_screen][4]
        else:
            return

        obc_event[sub_button]()

    def counter_submenu(self):
        if self.timeoutSubMenu > 0:
            log('OBCGUI: Submenu Counter restart', 2)
            self.timeoutSubMenu = 2000
            return
        if self.submenuCounter:
            self.timeoutSubMenu = 0
            self.submenuCounter.join()
            delete_object(self.submenuCounter)
        self.timeoutSubMenu = 2000
        log('OBCGUI: Submenu Counter start', 2)
        self.submenuCounter = Thread(target=self._counter_submenu)
        self.submenuCounter.daemon = True
        self.submenuCounter.start()

    def _counter_submenu(self):
        while self.timeoutSubMenu > 0:
            if not self.pause_submenu_counter:
                self.timeoutSubMenu -= 1
            time.sleep(0.001)
        self.reset_submenu()
        log('OBCGUI: Submenu Counter finshed', 2)

    def obcNext(self):
        if not True in [self.MAINLABEL[1][1],self.MAINLABEL[2][1],self.MAINLABEL[3][1],self.MAINLABEL[4][1]]:
            return

        self.obc_screen_next = True  # pause update
        if self.obc_screen == self.obc_screen_max:
            KODI.set_property('IBUSCOMMUNICATOR_OBC_Gauges', '0')
        else:
            KODI.set_property('IBUSCOMMUNICATOR_OBC_SLIDE', 'left_out')

        self.obc_screen += 1
        if self.obc_screen > self.obc_screen_max:
            inv_slide_direction = True
            self.obc_screen = self.obc_screen_min
        else:
            inv_slide_direction = False
        while not self.MAINLABEL[self.obc_screen][1]:
            self.obc_screen += 1
            if self.obc_screen > self.obc_screen_max:
                inv_slide_direction = True
                self.obc_screen = self.obc_screen_min
            else:
                inv_slide_direction = False

        time.sleep(0.5)  # wait for window animation
        self.obc_screen_next = False
        self.reset_submenu()
        if self.obc_screen == self.obc_screen_max and self.MAINLABEL[self.obc_screen_max][2]:
            KODI.set_property('IBUSCOMMUNICATOR_OBC_Gauges', '1')
        else:
            if inv_slide_direction:
                KODI.set_property('IBUSCOMMUNICATOR_OBC_SLIDE', 'left_in')
            else:
                KODI.set_property('IBUSCOMMUNICATOR_OBC_SLIDE', 'right_in')
            self.setFocus(self.BUTTON1[-1])

    def obcPrev(self):
        if not True in [self.MAINLABEL[1][1], self.MAINLABEL[2][1], self.MAINLABEL[3][1], self.MAINLABEL[4][1]]:
            return
        self.obc_screen_next = True
        if self.obc_screen == self.obc_screen_max and self.MAINLABEL[self.obc_screen_max][2]:
            KODI.set_property('IBUSCOMMUNICATOR_OBC_Gauges', '0')
        else:
            KODI.set_property('IBUSCOMMUNICATOR_OBC_SLIDE', 'right_out')

        self.obc_screen -= 1
        if self.obc_screen < self.obc_screen_min:
            inv_slide_direction = True
            self.obc_screen = self.obc_screen_max
        else:
            inv_slide_direction = False
        while not self.MAINLABEL[self.obc_screen][1]:
            self.obc_screen -= 1
            if self.obc_screen < self.obc_screen_min:
                inv_slide_direction = True
                self.obc_screen = self.obc_screen_max
            else:
                inv_slide_direction = False

        time.sleep(0.5)  # wait for window animation
        self.obc_screen_next = False
        self.reset_submenu()
        if self.obc_screen == self.obc_screen_max:
            KODI.set_property('IBUSCOMMUNICATOR_OBC_Gauges', '1')
        else:
            if inv_slide_direction:
                KODI.set_property('IBUSCOMMUNICATOR_OBC_SLIDE', 'right_in')
            else:
                KODI.set_property('IBUSCOMMUNICATOR_OBC_SLIDE', 'left_in')
            self.setFocus(self.BUTTON1[-1])


    def update(self, startup=False):
        '''
        if not EVENT.develop:
            if not EVENT.pi_is_visible and not EVENT.gt_av_r_manual:
                return
        '''

        def set_button_control(button, obc_screen):
            try:
                button[-1].setLabel(button[obc_screen][0])
            except:
                button[-1].setLabel(button[obc_screen][0]())

            try:
                button[-1].setVisible(button[obc_screen][1])
            except:
                button[-1].setVisible(button[obc_screen][1]())

            try:
                button[-1].setEnabled(button[obc_screen][2])
            except:
                button[-1].setEnabled(button[obc_screen][2]())

        def set_label_control(label, obc_screen):
            if label[obc_screen][0] != ' ':
                try:
                    label[-1].setLabel(label[obc_screen][0]())
                except TypeError:
                    label[-1].setLabel(label[obc_screen][0])
            else:
                label[-1].setLabel(' ')
            #label[-1].setVisible(label[obc_screen][1])
            #label[-1].setEnabled(label[obc_screen][2])

            # workaround for not empty string input
            if not label[obc_screen][1] or not label[obc_screen][2]:
                label[-1].setLabel(' ')

        def set_img_control(image, obc_screen):
            if len(image[obc_screen]) > 0:
                try:
                    image[-1].setVisible(image[obc_screen][0]())
                except TypeError:
                    image[-1].setVisible(image[obc_screen][0])
            else:
                image[-1].setVisible(False)

            try:
                image[-1].setImage(image[obc_screen][1](), False)
            except TypeError:
                image[-1].setImage(image[obc_screen][1], False)
            except IndexError:
                image[-1].setImage(ADDON_ICON_OBC, False)
                # control[-1].setVisibleCondition(control[obc_screen][0])


        #set_button_control(self.MAINLABEL, self.obc_screen)
        #set buttons
        #self.counter += 1
        #self.button_fl.setLabel('1234[CR]5678[CR]%s' % self.counter)

        self.button_fl.setLabel('%s[CR]%s[CR]%s' % (self.event_object.tire_pressure_get_label(FRONT_LEFT), self.event_object.tire_temperature_get_label(FRONT_LEFT), self.event_object.tires[FRONT_LEFT]['sensor_id']))
        self.button_fl.setVisible(True)
        self.button_fl.setEnabled(True)

        self.button_fr.setLabel('%s[CR]%s[CR]%s' % (self.event_object.tire_pressure_get_label(FRONT_RIGHT), self.event_object.tire_temperature_get_label(FRONT_RIGHT), self.event_object.tires[FRONT_RIGHT]['sensor_id']))
        self.button_fr.setVisible(True)
        self.button_fr.setEnabled(True)

        self.button_rl.setLabel('%s[CR]%s[CR]%s' % (self.event_object.tire_pressure_get_label(REAR_LEFT), self.event_object.tire_temperature_get_label(REAR_LEFT), self.event_object.tires[REAR_LEFT]['sensor_id']))
        self.button_rl.setVisible(True)
        self.button_rl.setEnabled(True)

        self.button_rr.setLabel('%s[CR]%s[CR]%s' % (self.event_object.tire_pressure_get_label(REAR_RIGHT), self.event_object.tire_temperature_get_label(REAR_RIGHT), self.event_object.tires[REAR_RIGHT]['sensor_id']))
        self.button_rr.setVisible(True)
        self.button_rr.setEnabled(True)

        #self.tire_fl.setColorDiffuse(self.event_object.tire_state_get_color(FRONT_LEFT))
        #self.tire_rl.setColorDiffuse(self.event_object.tire_state_get_color(REAR_LEFT))
        #self.tire_fr.setColorDiffuse(self.event_object.tire_state_get_color(FRONT_RIGHT))
        #self.tire_rr.setColorDiffuse(self.event_object.tire_state_get_color(REAR_RIGHT))

        set_property('script.service.tpms_tire_color_fl', self.event_object.tire_state_get_color(FRONT_LEFT))
        set_property('script.service.tpms_tire_color_rl', self.event_object.tire_state_get_color(REAR_LEFT))
        set_property('script.service.tpms_tire_color_fr', self.event_object.tire_state_get_color(FRONT_RIGHT))
        set_property('script.service.tpms_tire_color_rr', self.event_object.tire_state_get_color(REAR_RIGHT))

        self.battery_fl.setVisible(self.event_object.tire_low_battery_get_state(FRONT_LEFT))
        self.battery_rl.setVisible(self.event_object.tire_low_battery_get_state(REAR_LEFT))
        self.battery_fr.setVisible(self.event_object.tire_low_battery_get_state(FRONT_RIGHT))
        self.battery_rr.setVisible(self.event_object.tire_low_battery_get_state(REAR_RIGHT))

        self.signal_fl.setVisible(self.event_object.tire_lost_signal_get_state(FRONT_LEFT))
        self.signal_rl.setVisible(self.event_object.tire_lost_signal_get_state(REAR_LEFT))
        self.signal_fr.setVisible(self.event_object.tire_lost_signal_get_state(FRONT_RIGHT))
        self.signal_rr.setVisible(self.event_object.tire_lost_signal_get_state(REAR_RIGHT))


        '''
        # top arrows
        if self.obc_screen == self.obc_screen_max:
            self.mainright.setVisible(False)
        else:
            self.mainright.setVisible(True)
        if self.obc_screen == self.obc_screen_min:
            self.mainleft.setVisible(False)
        else:
            self.mainleft.setVisible(True)
        
        if not startup:
            if self.obc_screen_next:
                return
            elif self.obc_screen == self.obc_screen_max:
                set_gauges()
                return
                               
        if self.selectedButton != 1:
            set_button_control(self.BUTTON1, self.obc_screen)
            set_label_control(self.LABEL1, self.obc_screen)
            set_img_control(self.IMAGE1, self.obc_screen)
        if self.selectedButton != 2:
            set_button_control(self.BUTTON2, self.obc_screen)
            set_label_control(self.LABEL2, self.obc_screen)
            set_img_control(self.IMAGE2, self.obc_screen)
        if self.selectedButton != 3:
            set_button_control(self.BUTTON3, self.obc_screen)
            set_label_control(self.LABEL3, self.obc_screen)
            set_img_control(self.IMAGE3, self.obc_screen)
        if self.selectedButton != 4:
            set_button_control(self.BUTTON4, self.obc_screen)
            set_label_control(self.LABEL4, self.obc_screen)
            set_img_control(self.IMAGE4, self.obc_screen)
        if self.selectedButton != 5:
            set_button_control(self.BUTTON5, self.obc_screen)
            set_label_control(self.LABEL5, self.obc_screen)
            set_img_control(self.IMAGE5, self.obc_screen)
        if self.selectedButton != 6:
            set_button_control(self.BUTTON6, self.obc_screen)
            set_label_control(self.LABEL6, self.obc_screen)
            set_img_control(self.IMAGE6, self.obc_screen)
        if self.selectedButton != 7:
            set_button_control(self.BUTTON7, self.obc_screen)
            set_label_control(self.LABEL7, self.obc_screen)
            set_img_control(self.IMAGE7, self.obc_screen)
        if self.selectedButton != 8:
            set_button_control(self.BUTTON8, self.obc_screen)
            set_label_control(self.LABEL8, self.obc_screen)
            set_img_control(self.IMAGE8, self.obc_screen)
        '''

    def set_distance(self):
        if EVENT.obc_distance_unit == 'MLS':
            min_value = 1
            max_value = 6213
        else:
            min_value = 1
            max_value = 9999

        current_value = EVENT.obc_dist
        if current_value < min_value:
            current_value = min_value
        elif current_value > max_value:
            current_value = max_value

        if self.mouse_clicked:
            #result = int(xbmcgui.Dialog().numeric(0, 'Distance %s - %s' % (min_value, max_value), '%s' % current_value))
            result = int(xbmcgui.Dialog().numeric(0, 'Distance %s - %s' % (min_value, max_value)))
            if min_value > result > max_value or result == current_value:
                result = -1
            self.mouse_clicked = False
        else:
            self.pause_submenu_counter = True
            try:
                obc_set_value = ObcSetValueClass('OBC_SETVALUE.xml', ADDON_PATH, addon_skin_path(), '720p')
            except RuntimeError:
                obc_set_value = ObcSetValueClass('OBC_SETVALUE.xml', ADDON_PATH, 'default', '720p')

            result = obc_set_value.get_value(EVENT.obc_dist, min_value, max_value)


        log('Value set %s' % result)

        if result != -1:
            EVENT.obc_dist_set(result)

        #delete_object(obc_set_value)
        self.pause_submenu_counter = False

    def set_limit(self):
        if EVENT.obc_distance_unit == 'MLS':
            min_value = 4
            max_value = 199
        else:
            min_value = 6
            max_value = 299

        current_value = EVENT.obc_limit
        if current_value < min_value:
            current_value = min_value
        elif current_value > max_value:
            current_value = max_value

        if self.mouse_clicked:
            #result = int(xbmcgui.Dialog().numeric(0, 'Speed %s - %s' % (min_value, max_value), '%s' % current_value))
            result = int(xbmcgui.Dialog().numeric(0, 'Speed %s - %s' % (min_value, max_value)))
            if min_value > result > max_value or result == current_value:
                result = -1
            self.mouse_clicked = False
        else:
            self.pause_submenu_counter = True
            try:
                obc_set_value = ObcSetValueClass('OBC_SETVALUE.xml', ADDON_PATH, addon_skin_path(), '720p')
            except RuntimeError:
                obc_set_value = ObcSetValueClass('OBC_SETVALUE.xml', ADDON_PATH, 'default', '720p')

            if EVENT.obc_speed_unit == 'MPH':
                result = obc_set_value.get_value(EVENT.obc_limit, min_value, max_value)
            else:
                result = obc_set_value.get_value(EVENT.obc_limit, min_value, max_value)
        log('Value set %s' % result)

        if result != -1:
            EVENT.obc_limit_set(result)

        #delete_object(obc_set_value)
        self.pause_submenu_counter = False

    def set_timer(self, timer):
        if self.mouse_clicked:
            result = xbmcgui.Dialog().numeric(2, 'Time').split(':')
            if len(result) < 2:
                result = None
            result = [int(result[0]), int(result[1])]
            self.mouse_clicked = False
        else:
            self.pause_submenu_counter = True
            if EVENT.obc_time_unit == '12H' or not KODI.get_condition('String.IsEmpty(System.Time(xx))'):
                try:
                    obc_set_timer = ObcSetTimer12Class('OBC_SETTIMER12.xml', ADDON_PATH, addon_skin_path(), '720p')
                except RuntimeError:
                    obc_set_timer = ObcSetTimer12Class('OBC_SETTIMER12.xml', ADDON_PATH, 'default', '720p')
            else:
                try:
                    obc_set_timer = ObcSetTimer24Class('OBC_SETTIMER24.xml', ADDON_PATH, addon_skin_path(), '720p')
                except RuntimeError:
                    obc_set_timer = ObcSetTimer24Class('OBC_SETTIMER24.xml', ADDON_PATH, 'default', '720p')

            result = obc_set_timer.get_value()

        log('Value set %s' % result)

        if result:
            if timer == 1:
                EVENT.obc_tmr1_set(result[0], result[1])
            if timer == 2:
                EVENT.obc_tmr2_set(result[0], result[1])

        #delete_object(obc_set_timer)

        self.pause_submenu_counter = False


class TpmsFace(object):
    def __init__(self):
        log('SERIAL_VERSION: %s' % serial.VERSION)
        self.serial_port = serial.Serial()
        self.serial_port.baudrate = 19200
        self.serial_port.bytesize = serial.EIGHTBITS
        self.serial_port.parity = serial.PARITY_NONE
        self.serial_port.stopbits = serial.STOPBITS_ONE
        #self.serial_port.timeout = 5

        # Reading Thread
        self.read_thread_cancel = False
        self.read_thread = Thread(target=self._reading)
        self.read_thread.daemon = True

        self.func_callback = None

    def _reading(self):
        while not self.read_thread_cancel:
            a = ord(self.serial_port.read())
            if a == 0x55:
                b = ord(self.serial_port.read())
                if b == 0xAA:

                    cmd = ord(self.serial_port.read()) # 0x08
                    crc_temp = 0
                    crc_temp = crc_temp ^ a ^ b ^ cmd
                    data = []
                    for _ in range(0, cmd-4):
                        data.append(ord(self.serial_port.read()))
                        crc_temp = crc_temp ^ data[_]
                    '''
                    tire_id = ord(self.serial_port.read())
                    pressure = ord(self.serial_port.read())
                    temperature = ord(self.serial_port.read())
                    state = ord(self.serial_port.read())
                    '''
                    crc = ord(self.serial_port.read())

                    #log('MSG: %02X %02X %02X %02X %02X %02X %02X %02X' % (a, b, cmd, tire_id, pressure, temperature, state, crc))

                    if (crc_temp ^ crc) == 0:
                        #log('MSG: %02X %02X %02X %02X %02X %02X %02X %02X' % (a, b, cmd, tire_id, pressure, temperature, state, crc))
                        #package = [a, b, cmd, tire_id, pressure, temperature, state, crc]
                        package = [a, b, cmd, data, crc]
                        #log('new package: %s' % package)
                        if self.func_callback is not None:
                            self.func_callback(a, b, cmd, data, crc)

        log('Reading Stopped')

    def write_package(self, package):
        thread = Thread(target=self._writing, args=(package,))
        thread.daemon = True
        thread.start()

    def _writing(self, package):
            log('WRITING: %s' % package)
            # writing
            try:
                self.serial_port.write(bytearray(package))
            except serial.SerialException:
                log('ERROR: Can not write to Serial Port  >%s<' % self.serial_port.port)
                raise Exception('ERROR: Can not write to Serial Port  >%s<' % self.serial_port.port)

    def connect(self, device_path, func_callback):
        if platform.system() == 'Linux':
            if not os.path.exists(device_path):
                log('ERROR: Serial Port does not exist >%s<' % device_path)
                raise Exception('ERROR: Serial Port does not exist >%s<' % device_path)
        self.serial_port.port = device_path

        try:
            self.serial_port.open()
        except serial.SerialException:
            log('ERROR: Can not open Serial Port >%s<' % self.serial_port.port)
            raise

        self.func_callback = func_callback

        self.serial_port.timeout = None

        for _ in range(0, 1000):
            if self.serial_port.isOpen():
                break
            if _ == 1000:
                log('TIMEOUT-ERROR: Can not open Serial Port >%s<' % self.serial_port.port)
                raise SystemError
            xbmc.sleep(10)

        self.serial_port.timeout = 5

        self.serial_port.flushInput()
        self.serial_port.reset_input_buffer()

        # start reading
        self.read_thread.start()

        # start writing
        #self.write_thread.start()

    def disconnect(self):
        self.read_thread_cancel = True

        self.serial_port.timeout = 0.001

        try:
            self.read_thread.join()
        except RuntimeError:
            pass

        self.serial_port.close()


class EventClass(object):

    def __init__(self):
        self.tpms = None
        self.serial_dev = None

        self.debug = False
        self.develop = False
        self.simulate = False

        self.pressure_unit = 'kPa'
        self.pressure_unit_factor = 1.0

        self.pressure_low_limit = None
        self.pressure_low_limit_kpa = 180
        self.pressure_low_limit_bar = 1.8
        self.pressure_low_limit_psi = 26.1

        self.pressure_high_limit = None
        self.pressure_high_limit_kpa = 320
        self.pressure_high_limit_bar = 3.2
        self.pressure_high_limit_psi = 46.4

        self.temperature_unit = '°C'
        self.temperature_unit_factor = 1.0
        self.temperature_limit = None
        self.temperature_limit_c = 75
        self.temperature_limit_f = 167

        self.startup_done = False

        self.OBCGUI = None
        self.obc_screen = 0

        #https://www.digitaldutch.com/unitconverter/length.htm
        self.tire_presure_unit = '---' # KM/H, MPH

        self.tires = {'1': {'position' : 'front_left',
                             'pressure' : 1.0,
                             'temperature' : 20.0,
                             'lost_signal' : False,
                             'leaking' : False,
                             'low_battery' : False,
                            'sensor_id': 'FFFFFFFF'},
                      '2': {'position': 'front_right',
                             'pressure': 1.0,
                             'temperature': 20.0,
                             'lost_signal': False,
                             'leaking': False,
                             'low_battery': False,
                            'sensor_id': 'FFFFFFFF'},
                      '3': {'position': 'rear_left',
                             'pressure': 1.0,
                             'temperature': 20.0,
                             'lost_signal': False,
                             'leaking': False,
                             'low_battery': False,
                            'sensor_id': 'FFFFFFFF'},
                      '4': {'position': 'rear_right',
                             'pressure': 1.0,
                             'temperature': 20.0,
                             'lost_signal': False,
                             'leaking': False,
                             'low_battery': False,
                            'sensor_id': 'FFFFFFFF'},
                      '5': {'position': 'square',
                             'pressure': 1.0,
                             'temperature': 20.0,
                             'lost_signal': False,
                             'leaking': False,
                             'low_battery': False,
                            'sensor_id': 'FFFFFFFF'}
                      }

        self.obc_distance_unit = '---' # km/h and meter, imperial mph and yards
        self.obc_consumption_unit = '---' # L/100KM, mpg, km/l
        self.obc_fuel_unit = '' # L, gal Fuel
        self.pdc_unit = '' # METER (cm), INCH (in), FEET (ft)
        self.obc_network = "---"
        self.obc_language = "---"
        self.obc_time_unit = "---"
        self.obc_temperature_unit = '--'
        self.obc_engine = '---'

        self.shut_down = False
        self.tcp_server = None
        self.tcp_port = 8090
        self.tcp_server_shut_down = False

    def tcp_server_start(self):
        self.tcp_server = Thread(target=self.tcp_server_handle_events)
        self.tcp_server.daemon = True
        self.tcp_server.start()

    def tcp_server_stop(self):
        self.tcp_server_shut_down = True

        clientsocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        clientsocket.settimeout(0.001)
        #try:
        clientsocket.connect(('localhost', self.tcp_port))
        clientsocket.send('shutdown')
            #time.sleep(0.1)
            #answer = clientsocket.recv(50).replace('\n', '')
            #time.sleep(0.1)
            #clientsocket.shutdown(True)

        clientsocket.close()
        #try:
        self.tcp_server.join()
        #except:
        #    pass

        delete_object(self.tcp_server)
        self.tcp_server = None

    def tcp_server_handle_events(self):
        serversocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        serversocket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        serversocket.bind(('', self.tcp_port))  # '0.0.0.0'
        serversocket.listen(1)  # become a server socket, maximum 1 connections
        serversocket.setblocking(1)
        serversocket.settimeout(1)

        #while not xbmc.abortRequested:
        while not self.tcp_server_shut_down:
            # log('RXTX: TICK')
            # log('Threads: %s' % activeCount())
            if self.tcp_server_shut_down:
                break

            try:
                connection, address = serversocket.accept()
                connection.setblocking(1)
            except socket.timeout:
                if self.shut_down or self.tcp_server_shut_down:

                    break
                continue

            message = connection.recv(100)
            message = message.upper()

            given_args = message.split(';')

            if given_args[0] == 'SHUTDOWN':
                connection.send('OK\n\n')

                #break

            elif given_args[0] == 'OPENGUI':
                connection.send('OK\n\n')
                log('TCP %s: RECV >%s<' % (self.tcp_port, message))
                thread = Thread(target=self.gui_open)
                thread.daemon = True
                thread.start()


            elif given_args[0] == 'OBC' and given_args[1] == 'GET':
                log('TCP %s: RECV >%s<' % (self.tcp_port, message))
                # if given_args[2] == 'ODOMETER':
                position = EVENT.nav_position_get()

                value = {'IBusCommunicator': {
                    'time_unit': EVENT.obc_time_unit,
                    'speed_unit': EVENT.obc_speed_unit,
                    'distance_unit': EVENT.obc_distance_unit,
                    'consumption_unit': EVENT.obc_consumption_unit,
                    'fuel_unit': EVENT.obc_fuel_unit,
                    'temp_unit': EVENT.obc_temperature_unit,
                    'odometer': EVENT.obc_odometer,
                    'arrive': EVENT.obc_arr,
                    'consumption1': EVENT.obc_cons1,
                    'consumption2': EVENT.obc_cons2,
                    'vin': EVENT.obc_vin,
                    'distance': EVENT.obc_dist,
                    'range': EVENT.obc_range,
                    'fuel_level': EVENT.obc_fuellevel,
                    'gm_states': EVENT.gm_states,
                    'ike_states': EVENT.ike_states,
                    'outtemp': EVENT.obc_outtemp,
                    'coolant_c': EVENT.obc_coolant_C,
                    'coolant_f': EVENT.obc_coolant_F,

                }}
                if position:
                    value['IBusCommunicator'].update({"nav_states": {
                        "town": EVENT.nav_town_get(),
                        "gpsfix": EVENT.nav_gpsfix_get(),
                        "latitude": parse_dms(EVENT.nav_latitude_get()),
                        "longitude": parse_dms(EVENT.nav_longitude_get()),
                        "altitude": EVENT.nav_altitude_get(),
                        "street": EVENT.nav_street_get(),
                        "time": EVENT.nav_time_get()

                    }})
                connection.send('%s' % json.dumps(value, indent=4))

            elif given_args[0] == 'SENDIBUS':
                if EVENT.tcp_send_ibus:
                    try:
                        IBUS.write_hex_message(given_args[1])
                        connection.send('IBUSCOMMUNICATOR: >%s< sent to IBus\n\n' % given_args[1])
                        log('TCP %s: >%s< sent to IBus' % (self.tcp_port, given_args[1]))
                        note('Sent IBus-Message from TCP Port', '%s' % given_args[1], len(given_args[1]) * 100)
                    except:
                        connection.send('IBUSCOMMUNICATOR: >%s< ERROR not sent to IBus\n\n' % given_args[1])
                        log('TCP %s: >%s< not sent to IBus' % (self.tcp_port, given_args[1]))
                else:
                    connection.send('IBUSCOMMUNICATOR: send to IBus not enabled\n\n')
                    log('TCP %s: send to IBus not enabled' % self.tcp_port)

            elif given_args[0] == 'SIMULATEIBUS':
                EVENT.simulate_ibus_packages(given_args[1])
                connection.send('IBUSCOMMUNICATOR: >%s< simulate\n\n' % given_args[1])
                log('TCP %s: >%s< simulate' % (self.tcp_port, given_args[1]))
                note('Simulate IBus Message from TCP Port', '%s' % given_args[1], len(given_args[1]) * 100)
            else:
                connection.send('IBUSCOMMUNICATOR: unknown Command >%s< recieved\n\n' % message)
                log('TCP %s: unknown Command >%s< recieved' % (self.tcp_port, message))

            connection.close()

            #time.sleep(0.050)

        # serversocket.setblocking(0)
        # time.sleep(0.1)
        # serversocket.close()


        #serversocket.shutdown(socket.SHUT_RDWR)
        serversocket.close()

        log('TCP %s: CLOSED' % self.tcp_port)

    def simulate_ibus_packages(self, hex_message):
        hexstring_tmp = hex_message.upper().split(' ')
        src = int(hexstring_tmp[0], 16)
        len = int(hexstring_tmp[1], 16)
        dst = int(hexstring_tmp[2], 16)
        data = [int(s, 16) for s in hexstring_tmp[3:-1]]
        if hexstring_tmp[-1] == 'CK':
            xor = 0x00
        else:
            xor = int(hexstring_tmp[-1], 16)

        thread = Thread(target=self.manage, args=(src, len, dst, data, xor))
        thread.daemon = True
        thread.start()


    def manage(self, a, b, cmd, data, crc):
        '''
        package
        a 0x55):
        b 0xAA
        cmd 0x08,...
        tireID
        pressure
        temperature
        state
        crc
        '''
        #cmd = package[2]
        #data = package[3:-1]
        if cmd == 0x08:
            self.tire_state_put(data)
            log('MANAGE: TIRE STATE')
            return
        if cmd == 0x09:
            #log('got 09')
            #log(data)
            log('MANAGE: SENSOR ID')
            self.sensor_ids_put(data)


    def tire_state_put(self, data):
        #log(' '.join(['%02X' % i for i in data]))

        if data[0] == 0x00:  # Front Left
            tire_id = FRONT_LEFT
        elif data[0] == 0x01:  # Front Right
            tire_id = FRONT_RIGHT
        elif data[0] == 0x10:  # Rear Left
            tire_id = REAR_LEFT
        elif data[0] == 0x11:  # Rear Right
            tire_id = REAR_RIGHT
        elif data[0] == 0x05:  # Square
            tire_id = SQUARE

        self.tires[tire_id]['pressure'] = data[1] * 3.44 * self.pressure_unit_factor  # Bar
        if self.temperature_unit == '°C':
            self.tires[tire_id]['temperature'] = (data[2] - 50) # °C
        elif self.temperature_unit == '°F':
            self.tires[tire_id]['temperature'] = (data[2] - 50) * 1.8 + 32  # °F

        self.tires[tire_id]['lost_signal'] = (data[3] & 0b00100000) != 0  # lost signal
        self.tires[tire_id]['leaking'] = (data[3] & 0b00001000) != 0  # leaking
        self.tires[tire_id]['low_battery'] = (data[3] & 0b00001000) != 0  # low battery
        log('Tire: %s : %s : %s%s : %s%s : Lost Signal: %s : Leak: %s : Bat: %s' % (tire_id, self.tires[tire_id]['position'], self.tires[tire_id]['pressure'], self.pressure_unit, self.tires[tire_id]['temperature'], self.temperature_unit, self.tires[tire_id]['lost_signal'], self.tires[tire_id]['leaking'], self.tires[tire_id]['low_battery']))
        #log(json.dumps(self.tires))

    def tire_pressure_get_label(self, tire):
        return '%.1f %s' % (self.tires[tire]['pressure'], self.pressure_unit)

    def tire_temperature_get_label(self, tire):
        return '%.0f%s' % (self.tires[tire]['temperature'], self.temperature_unit)

    def tire_lost_signal_get_state(self, tire):
        return self.tires[tire]['lost_signal']

    def tire_leaking_get_state(self, tire):
        return self.tires[tire]['leaking'] and not self.tire_lost_signal_get_state(tire)

    def tire_state_get_color(self, tire):

        color = ADDON_TIRE_COLOR_GREY

        if self.tire_leaking_get_state(tire):
            return ADDON_TIRE_COLOR_RED


        if self.pressure_low_limit * 1.15 > self.tires[tire]['pressure'] > self.pressure_high_limit * 0.85:
            color = ADDON_TIRE_COLOR_GREEN

        if self.tires[tire]['pressure'] < self.pressure_low_limit:
            color = ADDON_TIRE_COLOR_RED

        if self.tires[tire]['pressure'] > self.pressure_high_limit:
            color = ADDON_TIRE_COLOR_RED

        if self.tires[tire]['pressure'] < self.pressure_low_limit * 1.15:  # 15%
            if color != ADDON_TIRE_COLOR_RED:
                color = ADDON_TIRE_COLOR_YELLOW

        if self.tires[tire]['pressure'] > self.pressure_high_limit * 0.85: # 15%
            if color != ADDON_TIRE_COLOR_RED:
                color = ADDON_TIRE_COLOR_YELLOW


        if self.tires[tire]['temperature'] > self.temperature_limit * 0.85:
            if color != ADDON_TIRE_COLOR_RED:
                color = ADDON_TIRE_COLOR_YELLOW

        if self.tires[tire]['temperature'] > self.temperature_limit:
            color = ADDON_TIRE_COLOR_RED

        if self.tires[tire]['temperature'] < self.temperature_limit * 0.85:
            if color != ADDON_TIRE_COLOR_RED and color != ADDON_TIRE_COLOR_YELLOW:
                color = ADDON_TIRE_COLOR_GREEN

            #if self.tire_lost_signal_get_state():
            #pass

        return color

    def tire_low_battery_get_state(self, tire):
        return self.tires[tire]['low_battery'] and not self.tire_lost_signal_get_state(tire)

    def sensor_ids_get(self):
        log('sensor request')
        self.tpms.write_package([0x55, 0xAA, 0x06, 0x07, 0x00, 0x00, 0x0C])

    def sensor_ids_put(self, data):
        tire_id = '%s' % data[0]
        self.tires[tire_id]['sensor_id'] = '%02X%02X%02X%02X' % (data[1], data[2], data[3], data[4])
        log('Tire: %s :%s'% (tire_id, self.tires[tire_id]['sensor_id']))
        #log(json.dumps(self.tires))

    def obc_dist_get(self):
        if self.obc_dist < -9999:
            return '---- %s' % self.obc_distance_unit
        else:
            return '%s %s' % (self.obc_dist, self.obc_distance_unit)


    def obc_avg_get(self):
        return '%s %s' % (self.obc_avg, self.obc_speed_unit)

    def obc_limit_reset(self):
        IBUS.write_bus_packet(0x3B, 0x80, [0x40, 0x09, 0xFF, 0xFF])  #
        time.sleep(1)
        self.obc_limit_enable(False)

    def obc_limit_enable(self, state):
        if state:
            IBUS.write_bus_packet(0x3B, 0x80, [0x41, 0x09, 0x04])  # 3B 05 80 41 09 04 F2
        else:
            IBUS.write_bus_packet(0x3B, 0x80, [0x41, 0x09, 0x08])  # 3B 05 80 41 09 08 FE


    def obc_coolant_get_icon(self):
        if self.obc_coolant_C <= 25:
            return ADDON_ICON_COOLANT_BLUE
        if self.obc_coolant_C <= 75:
            return ADDON_ICON_COOLANT_YELLOW
        if self.engine_overheat_warning:
            if self.obc_coolant_C < self.engine_overheat_temp:
                return ADDON_ICON_COOLANT_GREEN
            if self.obc_coolant_C >= self.engine_overheat_temp:
                return ADDON_ICON_COOLANT_RED
        else:
            if self.obc_coolant_C < 100:
                return ADDON_ICON_COOLANT_GREEN
            if self.obc_coolant_C >= 100:
                return ADDON_ICON_COOLANT_RED


    def gui_open(self):
        # log('OBC: current Window ID: %s' % xbmcgui.getCurrentWindowId())
        if xbmcgui.getCurrentWindowDialogId() == 10140:  # AddonSettings
            KODI.back()

        if self.OBCGUI:
            if self.gui_is_visible():
                self.gui_close()

            elif self.OBCGUI.isActive:
                self.gui_close()
                time.sleep(0.5)
                self.gui_show()
            else:
                self.gui_show()
        else:
            self.gui_show()

    def gui_show(self):
        log('Current selected ADDON SKIN: %s' % addon_skin_path())
        self.OBCGUI = GuiClass("OBC_SKIN.xml", ADDON_PATH, addon_skin_path(), '720p')
        self.OBCGUI.obc_screen = self.obc_screen
        self.OBCGUI.event_object = self
        self.OBCGUI.doModal()
        self.obc_screen = self.OBCGUI.obc_screen

    def gui_close(self):
        if self.OBCGUI:
            self.obc_screen = self.OBCGUI.obc_screen
            self.OBCGUI.onStop()
            delete_object(self.OBCGUI)

    def gui_is_visible(self):
        if self.OBCGUI:
            return self.OBCGUI.isVisible()
        else:
            return False

    def simulate_values(self):
        if self.simulate:
            set_property('TPMS_TIRE_TEMP_FL', '%s' % 20)
            set_property('TPMS_TEMP_UNIT', '%s' % '°C')

    def load_settings(self, settings_changed=False):

        setting_tmp = None

        # TCP
        self.tcp_port = int(get_addon_setting('tcp_port'))
        log('SETTING: TCP_PORT=%s' % self.tcp_port)


        # Serial device
        if platform.system().lower() == 'linux':
            setting_tmp = get_addon_setting('ser_dev_lin')
            ser_dev_custom = get_addon_setting('ser_dev_lin_custom')
        elif platform.system().lower() == 'windows':
            setting_tmp = get_addon_setting('ser_dev_win')
            ser_dev_custom = get_addon_setting('ser_dev_lin_custom')
        elif platform.system().lower() == 'android':
            setting_tmp = get_addon_setting('ser_dev_and')
            ser_dev_custom = get_addon_setting('ser_dev_lin_custom')

        if setting_tmp.lower() == 'custom':
            setting_tmp = ser_dev_custom

        self.serial_dev = setting_tmp
        log('SETTING: SERIAL_DEVICE=%s' % self.serial_dev)


        # Pressure Unit
        setting_tmp = int(get_addon_setting('pressure_unit'))

        if setting_tmp == 0: #kPa
            self.pressure_unit = 'kPa'
            self.pressure_unit_factor = 1.0 #3.44
            self.pressure_low_limit = int(get_addon_setting('pressure_low_limit_kpa'))
            self.pressure_high_limit = int(get_addon_setting('pressure_high_limit_kpa'))
        elif setting_tmp == 1: #Bar
            self.pressure_unit = 'Bar'
            self.pressure_unit_factor = 0.01 #0.0344
            self.pressure_low_limit = float(get_addon_setting('pressure_low_limit_bar'))
            self.pressure_high_limit = float(get_addon_setting('pressure_high_limit_bar'))
        elif setting_tmp == 2: #PSi
            self.pressure_unit = 'PSI'
            self.pressure_unit_factor = 0.145038
            self.pressure_low_limit = float(get_addon_setting('pressure_low_limit_psi'))
            self.pressure_high_limit = float(get_addon_setting('pressure_high_limit_psi'))
        log('SETTING: PRESSURE_UNIT=%s' % self.pressure_unit)
        log('SETTING: PRESSURE_UNIT_FACTOR=%s' % self.pressure_unit_factor)
        log('SETTING: PRESSURE_LOW_LIMIT=%s' % self.pressure_low_limit)
        log('SETTING: PRESSURE_HIGH_LIMIT=%s' % self.pressure_high_limit)


        # Temperature Unit
        setting_tmp = int(get_addon_setting('temperature_unit'))

        if setting_tmp == 0:  # °C
            self.temperature_unit = '°C'
            self.temperature_unit_factor = 1
            self.temperature_limit = int(get_addon_setting('temperature_limit_c'))
        elif setting_tmp == 1:  # Bar
            self.temperature_unit = '°F'
            self.temperature_unit_factor = 33.8
            self.temperature_limit = int(get_addon_setting('temperature_limit_f'))
        log('SETTING: TEMPERATURE_UNIT=%s' % self.temperature_unit)
        log('SETTING: TEMPERATURE_UNIT_FACTOR=%s' % self.temperature_unit_factor)
        log('SETTING: TEMPERATURE_LIMIT=%s' % self.temperature_limit)


        # special modes
        self.debug = get_addon_setting('debug')
        log('SETTING: DEBUG=%s' % self.debug)
        self.develop = get_addon_setting('develop')
        log('SETTING: DEVELOP=%s' % self.develop)
        self.simulate = get_addon_setting('simulate')
        log('SETTING: SIMULATE=%s' % self.simulate)


        ################### LOADING SETTINGS FINISHED #######################


        # Log level
        self.log_level = int(get_addon_setting('log_lvl'))
        log('SETTING: LOAD: LOG_LEVEL=%s' % self.log_level, 0)


        if settings_changed:
            pass

    def change_settings(self):
        self.load_settings(True)
        note('Settings changed', 'Reloading Done', 1000)

    def shutdown(self):
        self.shut_down = True
        self.tcp_server_stop()
        log("TPMS: Disconnecting")
        self.tpms.disconnect()
        log("TPMS: Disconnected")


def log(string, log_level=1):
    xbmc.log('%s: %s' % (ADDON_ID, string), xbmc.LOGNOTICE)


def note(heading, message=None, time=-1, icon=None):
    if time == -1:
        xbmcgui.Dialog().notification(heading='%s' % heading, message='%s' % message if message else ' ', icon='%s' % (icon if icon else ADDON_ICON))
    else:
        xbmcgui.Dialog().notification(heading='%s' % heading, message='%s' % message if message else ' ', icon='%s' % (icon if icon else ADDON_ICON), time=time)
    log('NOTIFICATION: "%s%s"' % (heading, ' - %s' % message if message else ''))


def dialog_ok(label1, label2=None, label3=None):
    log('DIALOG_OK: "%s%s%s"' % (label1, ' - %s' % label2 if label2 else '', ' - %s' % label3 if label3 else ''))
    xbmcgui.Dialog().ok(ADDON_NAME, label1, label2, label3)


def dialog_yesno(label1, label2=None, label3=None, nolabel='', yeslabel='', autoclose=0):
    return xbmcgui.Dialog().yesno(ADDON_NAME, line1=label1, line2=label2, line3=label3, nolabel=nolabel, yeslabel=yeslabel, autoclose=autoclose)

def get_addon_setting(id):
    setting = xbmcaddon.Addon().getSetting(id)
    #setting = ADDON.getSetting(id)
    if setting.upper() == 'TRUE': return True
    if setting.upper() == 'FALSE': return False
    return '%s' % setting


def set_addon_setting(id, value):
    if type(value) == 'bool':
        ADDON.setSetting(id, 'true' if value else 'false')
    else:
        ADDON.setSetting(id, '%s' % value)


def get_property(property, id=10000):
    xbmcgui.Window(id).getProperty(property)


def set_property(property, value, id=10000):
    xbmcgui.Window(id).setProperty(property, value)

def clear_property(property, id=10000):
    value = xbmcgui.Window(id).clearProperty(property)

def get_addon_string(id, replacements=None):
    string = ADDON.getLocalizedString(id)
    if replacements is not None:
        return string % replacements
    else:
        return string


def addon_skin_path():
    current_skin_name = xbmc.getSkinDir()
    #log('Skin: %s' % current_skin_name)
    if os.path.exists(os.path.join(ADDON_PATH, 'resources', 'skins', current_skin_name)):
        return '%s' % current_skin_name
    else:
        return 'default'

def delete_object(object):
    xbmc.log('Objectcount: %s' % sys.getrefcount(object), xbmc.LOGNOTICE)
    try:
        while sys.getrefcount(object) >= 0:
            del object
    except NameError:
        pass




def main():
    if not get_addon_setting('autorun'):
        return

    xbmc.log('%s: Service Starting...' % ADDON_ID, xbmc.LOGNOTICE)

    log('STARTUP: TPMS VERSION: %s' % ADDON_VERSION)
    #log('STARTUP: KODI GUI VERSION: %s' % Kodi().get_gui_version())


    if not os.path.isdir(ADDON_USER_PATH): #xbmcvfs.exists(ADDON_USER_PATH):
        xbmcvfs.mkdir(ADDON_USER_PATH)
        log('STARTUP: ADDON_USER_PATH "%s" created' % ADDON_USER_PATH)



    log('STARTUP: LOAD SETTINGS...')
    #load_settings()

    event = EventClass()

    event.tpms = TpmsFace()

    event.load_settings()

    log('STARTUP: TPMS: Connecting...')

    try:
        event.tpms.connect(event.serial_dev, event.manage)
    except:
        note('Error', 'Connection failed')
        time.sleep(2)
        if not event.develop:
            raise

    event.tcp_server_start()

    monitor = MonitorClass()
    monitor.set_settings_changed_callback(event.change_settings)

    if event.develop:
        note(heading='[COLOR FFFF7E00]%s[/COLOR]' % language('Development Mode'), message='[B]%s[/B]' % language('Continue without IBus Connection'))
    else:
        note('TPMS Connected')

    log('STARTUP: FINISHED :)')




    time.sleep(5)
    event.sensor_ids_get()




    try:
        if xbmc.Monitor().waitForAbort(): #holds during kodi is running
            pass
    except:
        pass

    log('Service Shutting Down.....')

    event.shutdown()
    #time.sleep(1)

    xbmc.log('%s: Service Stopped' % ADDON_ID, xbmc.LOGNOTICE)


if __name__ == '__main__':
    main()
