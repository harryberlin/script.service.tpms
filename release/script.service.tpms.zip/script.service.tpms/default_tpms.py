#!/usr/bin/env python
# -*- coding: utf-8 -*-

# webservice
# https://github.com/arsac/pimmer

__author__ = 'harryberlin'

import os
import sys
import platform


import xbmc, xbmcaddon, xbmcvfs, xbmcgui


ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_USER_PATH = os.path.join(xbmc.translatePath('special://userdata'), 'addon_data', ADDON_ID)

ICON = os.path.join(ADDON_PATH, 'icon.png')

PLATFORM = platform.system()
PLATFORM_OSMC = True
PLATFORM_LIBREELEC = False
PLATFORM_CONFIG_DIR = os.path.join(os.path.sep, 'boot')
PLATFORM_HOME_DIR = os.path.join(os.path.sep, 'home','osmc')
PLATFORM_SUDO = 'sudo '


ACTION_PARENT_DIR = 9
ACTION_PREVIOUS_MENU = 10
ACTION_CLOSE_DIALOG = 51
ACTION_SELECT_ITEM = 7
ACTION_MOVE_LEFT = 1
ACTION_MOVE_RIGHT = 2
ACTION_MOVE_UP = 3
ACTION_MOVE_DOWN = 4
ACTION_NAV_BACK = 92
ACTION_BACKSPACE = 110


def log(string, lvl=0):
    return xbmc.log('%s: %s' % (ADDON_ID, string), xbmc.LOGNOTICE)


def note(heading, message=None, time=5000):
    import xbmcgui
    xbmcgui.Dialog().notification(heading='%s' % heading, message='%s' % message if message else '', icon=ICON, time=time)
    log('NOTIFICATION: "%s%s"' % (heading, ' - %s' % message if message else ''))


def dialog_ok(label1, label2='', label3=''):
    import xbmcgui
    return xbmcgui.Dialog().ok('IBusCommunicator', label1, label2, label3)


def get_addon_setting(id):
    # setting = xbmcaddon.Addon().getSetting(id)
    setting = ADDON.getSetting(id)
    if setting.upper() == 'TRUE': return True
    if setting.upper() == 'FALSE': return False
    return '%s' % setting


def set_addon_setting(id, value):
    if type(value) == 'bool':
        ADDON.setSetting(id, 'true' if value else 'false')
    else:
        ADDON.setSetting(id, '%s' % value)


def get_property(property, id=10000):
    import xbmcgui
    return xbmcgui.Window(id).getProperty(property)

def set_property(property, value, id=10000):
    import xbmcgui
    xbmcgui.Window(id).setProperty(property, value)

def _pbhook(numblocks, blocksize, filesize, url=None, dp=None):
    if dp.iscanceled():
        print "Download Abgebrochen"
        raise Exception("dialog canceled")
        #dp.close()

    try:
        percent = min((numblocks * blocksize * 100) / filesize, 100)
        current_size = '%.*f' % (2, numblocks*blocksize/1024.0/1024.0)
        total_size = '%.*f' % (2, filesize/1024.0/1024.0)
        print percent
        teststr = '%s / %s MB / %s%%' % (current_size, total_size, percent)
        dp.update(int(10+percent*0.4), 'Downloading...', teststr, '%s%%' % int(10+percent*0.4))
    except:
        pass
        #percent = 100
        #dp.update(percent)


def is_internet_available():
    import urllib2
    try:
        urllib2.urlopen('http://216.58.192.142', timeout=5)
        return True
    except:
        return False


def _send_command(message):
    import time
    import socket
    clientsocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    clientsocket.settimeout(0.1)
    port = int(get_addon_setting('tcp_port'))
    try:
        clientsocket.connect(('localhost', port))
    except:
        return False

    log('# TCP %s: SEND >%s<' % (port, message.upper()))
    clientsocket.send(message)
    time.sleep(0.2)
    answer = clientsocket.recv(50).replace('\n','')
    time.sleep(0.2)
    clientsocket.shutdown(True)
    if answer == 'OK':
        return True
    else:
        return False

def dialog_progressbar_timeout(dp, line_1, line_2, line_3, timeout=3000):
    for _ in range(100, 0, -1):
        if dp.iscanceled():
            break
        dp.update(_, line_1, line_2, line_3)
        xbmc.sleep(timeout/100)


def update(owner, repo, branch='master'):
    # https://stackoverflow.com/questions/44282418/extracting-zip-overwrite-by-default
    import json
    import urllib
    import urllib2
    import zipfile
    dp = xbmcgui.DialogProgress()
    dp.create('Updating %s-Beta' % ADDON_NAME, ' ')
    dp.update(1, 'Check Connection...', ' ', '1%')

    try:
        if not is_internet_available():
            raise Exception('No Internet connection')

        dp.update(5, 'Check for new Version on github...', ' ', '5%')
        try:
            url = 'https://api.github.com/repos/%s/%s/git/refs/heads/%s' % (owner, repo, branch)

            res = json.loads(urllib2.urlopen(url).read())
            log(res)

            sha_url = res['object']['url']

            res = json.loads(urllib2.urlopen(sha_url).read())
            commit_date = res['committer']['date']
            try:
                commit_message = res['message']
            except:
                commit_message = '---------'
            sha = res['sha']
        except:
            raise Exception('Try again later')

        log(sha)

        #raise Exception('%s' % get_addon_setting('github_sha'))

        try:
            import resources.lib.test
        except ImportError:
            if ADDON.getSettingString('github_sha') == sha:
                raise Exception('No Update required')

        print 'downloading file'

        dp.update(10, 'Downloading...', ' ', '10%')
        url = 'https://github.com/harryberlin/plugin.script.ibuscommunicator/raw/master/plugin.script.ibuscommunicator-beta.zip'

        target_path = os.path.join(ADDON_USER_PATH, 'plugin.script.ibuscommunicator-beta.zip')

        # https://www.programcreek.com/python/example/663/urllib.urlretrieve

        urllib.urlretrieve(url, target_path, lambda nb, bs, fs, url=url: _pbhook(nb, bs, fs, url, dp))

        dp.update(50, 'Check Zipfile...', ' ', '50%')

        the_zip_file = zipfile.ZipFile(target_path, 'r')
        ret = the_zip_file.testzip()

        if ret is not None:
            raise Exception('Zipfile is bad')

        dp.update(50, 'Checked Zipfile', ' ', '50%')

        zip_count = 0
        zip_max_count = len(the_zip_file.infolist())

        #import shutil
        os.remove(ADDON_PATH + '/resources/lib/pibus') #, ignore_errors=False)

        for zipinfo in the_zip_file.infolist():
            zip_count += 1

            if zipinfo.filename.startswith('plugin.script.ibuscommunicator'):
                #%s' % os.path.split(zipinfo.filename)[1]
                zipinfo.filename = zipinfo.filename.replace('plugin.script.ibuscommunicator', '')

                dp.update(int(50+int(float(zip_count)/float(zip_max_count)*100)*0.50), 'Extracting... %s' % os.path.split(zipinfo.filename)[1], '%s / %s / %s%%' % (zip_count, zip_max_count, int(float(zip_count)/float(zip_max_count)*100)), '%s%%' % int(50+int(float(zip_count)/float(zip_max_count)*100)*0.50))
                #os.path.split(zipinfo.filename)[1]
                #the_zip_file.extract(zipinfo, os.path.join(ADDON_PATH, 'test'))

                try:
                    import resources.lib.test
                    # for testing to don't overwrite myself
                    the_zip_file.extract(zipinfo, os.path.join(ADDON_PATH, 'test'))
                    #raise Exception('was imported')
                    pass
                except ImportError:
                    # for working release
                    the_zip_file.extract(zipinfo, ADDON_PATH)
                    #raise Exception('was not imported')
                    pass


        the_zip_file.close()

        set_addon_setting('github_sha', '%s' % sha)
        xbmc.sleep(400)
        #date_string = datetime.datetime.strptime(commit_date, '%Y-%m-%dT%H:%M:%SZ')

        commit_str_date = '%s' % (commit_date.replace('T', ' ').replace('Z', ' '))

        dialog_progressbar_timeout(dp, 'Update done. REBOOT REQUIRED', 'Release: %s' % commit_str_date, '%s' % commit_message, 7000)

        #xbmc.executebuiltin("Notification(Skin Updater,Update erfolgreich!,5000)")

        xbmc.executebuiltin("XBMC.UpdateLocalAddons()")

    except Exception as e:
        dialog_progressbar_timeout(dp, e.message, ' ', ' ', 7000)

    finally:
        #the_zip_file.close()
        dp.close()


def open_obcgui():
    if not _send_command('opengui'):
        note('Error by opening OBC GUI')


def open_settings():
    import xbmcgui
    # log('Window: %s' % xbmcgui.getCurrentWindowId())
    # log('Dialog: %s' % xbmcgui.getCurrentWindowDialogId())
    if xbmcgui.getCurrentWindowDialogId() == 10140:
        xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Back", "id": 1 }')
    else:
        xbmcaddon.Addon().openSettings()



def test():
    import xbmcgui
    win = xbmcgui.Window(xbmcgui.getCurrentWindowId())
    current_control = win.getControl(win.getFocusId())
    # listitem = current_control......getLabel()

    # log("TEST: %s" % listitem)


def is_osmc():
    if 'osmc' in  os.popen('uname -n').read().lower():
        return True
    else:
        return False

def is_libreelec():
    if 'libreelec' in  os.popen('uname -n').read().lower():
        return True
    else:
        return False

def is_windows():
    if 'windows' in  platform.system().lower():
        return True
    else:
        return False

def is_rasp_2():
    if 'raspberry pi 2' in os.popen('dmesg | grep "Raspberry.Pi.2"').read().lower():
        return True
    else:
        return False

def is_rasp_3():
    if 'raspberry pi 3' in os.popen('dmesg | grep "Raspberry.Pi.3"').read().lower():
        return True
    else:
        return False

def set_platform():
    global PLATFORM_OSMC, PLATFORM_LIBREELEC, PLATFORM_WINDOWS, PLATFORM_CONFIG_DIR, PLATFORM_HOME_DIR
    global PLATFORM_SUDO, PLATFORM_KODI_LOGFILE, PLATFORM_EXPORT_LOGFILE_PATH, PIBUS_LOGFILE, PIBUS_LOGFILE_PATH

    if is_osmc():
        PLATFORM_OSMC = True
        PLATFORM_LIBREELEC = False
        PLATFORM_WINDOWS = False
        PLATFORM_CONFIG_DIR = os.path.join(os.path.sep, 'boot')
        PLATFORM_HOME_DIR = os.path.join(os.path.sep, 'home', 'osmc')
        PLATFORM_SUDO = 'sudo '
        PIBUS_LOGFILE_PATH = os.path.join(os.path.sep, 'root')
        PIBUS_LOGFILE = os.path.join(PIBUS_LOGFILE_PATH, 'ibus.txt')
    elif is_libreelec():
        PLATFORM_OSMC = False
        PLATFORM_LIBREELEC = True
        PLATFORM_WINDOWS = False
        PLATFORM_CONFIG_DIR = os.path.join(os.path.sep, 'storage')
        PLATFORM_HOME_DIR = os.path.join(os.path.sep, 'storage')
        PLATFORM_SUDO = ''
        PIBUS_LOGFILE_PATH = os.path.join(os.path.sep, 'storage')
        PIBUS_LOGFILE = os.path.join(PIBUS_LOGFILE_PATH, 'ibus.txt')
    elif is_windows():
        PLATFORM_OSMC = False
        PLATFORM_LIBREELEC = False
        PLATFORM_WINDOWS = True
        PLATFORM_CONFIG_DIR = ADDON_USER_PATH
        PLATFORM_HOME_DIR = ADDON_USER_PATH
        PLATFORM_SUDO = ''
        PIBUS_LOGFILE_PATH = ADDON_USER_PATH
        PIBUS_LOGFILE = os.path.join(ADDON_USER_PATH, 'ibus.txt')
    else: # windows too
        PLATFORM_OSMC = False
        PLATFORM_LIBREELEC = False
        PLATFORM_WINDOWS = False
        PLATFORM_CONFIG_DIR = ADDON_USER_PATH
        PLATFORM_HOME_DIR = ADDON_USER_PATH
        PLATFORM_SUDO = ''
        PIBUS_LOGFILE_PATH = ADDON_USER_PATH
        PIBUS_LOGFILE = os.path.join(ADDON_USER_PATH, 'ibus.txt')

    PLATFORM_KODI_LOGFILE = os.path.join(PLATFORM_HOME_DIR, '.kodi', 'temp', 'kodi.log')
    PLATFORM_EXPORT_LOGFILE_PATH = os.path.join(PLATFORM_CONFIG_DIR, 'ibuscommunicator')


    log('STARTUP: PLATFORM_OSMC: [%s]' % PLATFORM_OSMC)
    log('STARTUP: PLATFORM_LIBREELEC: [%s]' % PLATFORM_LIBREELEC)
    log('STARTUP: PLATFORM_WINDOWS: [%s]' % PLATFORM_WINDOWS)
    log('STARTUP: PLATFORM_CONFIG_DIR: [%s]' % PLATFORM_CONFIG_DIR)
    log('STARTUP: PLATFORM_HOME_DIR: [%s]' % PLATFORM_HOME_DIR)
    log('STARTUP: PLATFORM_SUDO: [%s]' % PLATFORM_SUDO)
    log('STARTUP: PLATFORM_KODI_LOGFILE: [%s]' % PLATFORM_KODI_LOGFILE)
    log('STARTUP: PLATFORM_EXPORT_LOGFILE_PATH: [%s]' % PLATFORM_EXPORT_LOGFILE_PATH)


def call(command):
    log('CONSOLE CMD: [%s%s]' % (PLATFORM_SUDO, command), 3)
    return os.popen('%s%s' % (PLATFORM_SUDO, command)).read()

def main():
    set_platform()
    # Start Script
    count = len(sys.argv) - 1
    if count > 0:
        given_args = sys.argv[1].split(';')
        if str(given_args[0]) == "opengui":
            open_obcgui()
        elif str(given_args[0]) == "settings":
            open_settings()
        elif str(given_args[0]) == 'update-beta':
            update('harryberlin', 'script.service.tpms')

        elif str(given_args[0]) == "test":
            test()
        else:
            # set_url_list(urlname=str(given_args[0]))
            note('Unknown Arguments given!','%s' % given_args)

    else:
        open_settings()
        # xbmcgui.Dialog().ok('IBusCommunictor','IBusCommunictor')


if __name__ == '__main__':
    main()
